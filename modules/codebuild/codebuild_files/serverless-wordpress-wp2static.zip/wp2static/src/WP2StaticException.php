<?php

namespace WP2Static;

use Exception;

class WP2StaticException extends Exception {
}

